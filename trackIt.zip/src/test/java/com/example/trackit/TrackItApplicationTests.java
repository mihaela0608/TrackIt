package com.example.trackit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackItApplicationTests {

    @Test
    void contextLoads() {
    }

}
